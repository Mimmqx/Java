
package Graphics;
import java.awt.Canvas;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.geom.Line2D;
import static java.lang.Math.sqrt;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import sk.stuba.fei.oop.ArcSource;
import sk.stuba.fei.oop.PetriNet;
import sk.stuba.fei.oop.PlaceSource;
import sk.stuba.fei.oop.PlaceTransitionArc;
import sk.stuba.fei.oop.TransitionPlaceArc;
import sk.stuba.fei.oop.TransitionSource;
import sk.stuba.fei.oop.Vertex;

public class Screen extends Canvas implements MouseListener,MouseMotionListener{
    
    private List<GeometricalObject> objects;
    private List<PlaceSource> places;
    private List<TransitionSource> transitions;
    private List<ArcSource> arcs;
    private int IDt;
    private int IDm;
    private int IDp;
    private int IDa;
    private List<Vertex> objectss = new ArrayList<>();
    private boolean plusTokens = false;
    private boolean minusTokens = false;
    protected boolean play = true;
    private boolean drawCircle = false;
    private boolean drawTransition = false;
    private boolean drawArrow = false;
    private boolean RemoveObject = false;
    private boolean MoveObject = false;
    private boolean Buttonpressed = false;
    private HashMap<Long, Line2D> lines;
    private PetriNet net;
    
    protected void setMove(boolean move){
        this.MoveObject = move;
    }
    protected PetriNet getNet(){
        return this.net;
    } 
    protected List<TransitionSource> getTransitions(){
        return this.transitions;
    }
    protected void setDrawArrow(boolean setArrow){
        this.drawArrow = setArrow;
    }
    protected void setdrawTransition(boolean setTransition){
        this.drawTransition = setTransition;
    }
    protected void setDrawCircle(boolean setcircle){
        this.drawCircle = setcircle;
    }
    protected void setRemove(boolean remove){
        this.RemoveObject = remove;
    }
    protected void setButtons(boolean play,boolean plus, boolean minus, boolean circle, boolean transition, boolean arrow, boolean remove, boolean move){
        this.play = play;
        this.plusTokens = plus;
        this.minusTokens = minus;
        this.drawCircle = circle;
        this.drawTransition = transition;
        this.drawArrow = arrow;
        this.RemoveObject = remove;
        this.MoveObject = move; 
    }

    protected void setMinusTokens(boolean minusTokens){
        this.minusTokens = minusTokens;
    }
    protected boolean getMinusTokens(){
        return this.minusTokens;
    }
    protected void setPlusTokens(boolean plusTokens){
        this.plusTokens = plusTokens;
    }
    protected boolean getPlusTokens()
    {
        return this.plusTokens;
    }
    protected void clearList(){
        objects.clear();
        places.clear();
        transitions.clear();
        arcs.clear();
    }
    public Screen() {
        super();
        this.objects = new ArrayList<>();
        this.places = new ArrayList<>();
        this.transitions = new ArrayList<>();
        this.arcs = new ArrayList<>();
        this.lines = new HashMap();
        addMouseListener(this);
        addMouseMotionListener(this);
    }
    protected void clearLists(){
        this.places.clear();
        this.arcs.clear();
        this.transitions.clear();
    }
    private void addPlacess (PetriNet net){
            for(Map.Entry<Long,PlaceSource> map : net.getPlaces().entrySet()){
            addGeometricalObject(new Circle((int)(long) map.getValue().getX(),(int)(long) map.getValue().getY(),20,map.getValue().getTitle(), map.getValue().getMarking()));
            addPlace(map.getValue());
        }
    }
    private void addTransitionss(PetriNet net){
            for(Map.Entry<Long,TransitionSource> map : net.getTransitions().entrySet()){
                addGeometricalObject(new Square((int)(long) map.getValue().getX(),(int)(long) map.getValue().getY(),40,map.getValue().isFireable(),map.getValue().getTitle()));
                addTransition(map.getValue());
        }
    }
    private void addArcss(PetriNet net){
            for(ArcSource entry : net.getArcs()){
            addGeometricalObject(new Arrow((int)(long)entry.getSource().getX(),(int)(long)entry.getSource().getY(),(int)(long)entry.getDestination().getX(),(int)(long)entry.getDestination().getY(),"",entry.getMultiplicity()));
            addArc(entry);
        }
    }
    
    protected void PN(PetriNet net){
        this.net = net;
        clearList();
        addPlacess(this.net);
        addTransitionss(this.net);
        addArcss(this.net);
    }
    protected void addTransition(TransitionSource t){
        this.transitions.add(t);
    }
    protected void addGeometricalObject(GeometricalObject object){
        this.objects.add(object);
    }
    private void addObject(Vertex object){
        this.objectss.add(object);
    }
    protected void addPlace(PlaceSource p){
        this.places.add(p);
    }
    protected void addPlaces(){
       for(PlaceSource place : places){
           Circle circle = new Circle((int)(long)place.getX(),(int)(long)place.getY(),20,place.getTitle(),place.getMarking());
           addGeometricalObject(circle);
       }
    }
    protected void addTransitions(){
         for(TransitionSource transition : transitions){
           Square square = new Square((int)(long)transition.getX(),(int)(long)transition.getY(),40,transition.isFireable(),transition.getTitle());
           addGeometricalObject(square);
       }
    }
    protected void addTransitions(TransitionSource t){
        this.transitions.add(t);
    }
    protected void addArcs(){
          for(ArcSource arc : arcs){
           Arrow arrow = new Arrow((int)(long)arc.getSource().getX(),(int)(long)arc.getSource().getY(),(int)(long)arc.getDestination().getX(),(int)(long)arc.getDestination().getY(),"",arc.getMultiplicity());
           addGeometricalObject(arrow);
           this.lines.put(arc.getID(), arrow.getLine());
       }
    }
    protected void addArc(ArcSource a){
        this.arcs.add(a);
    }
    @Override
    public void paint(Graphics g) {
        setBackground(Color.white);
        for(GeometricalObject gt:objects){
            gt.draw(g);
        }
    }

    protected List<GeometricalObject> getGeomTtvary() {
        return objects;
    }

    protected void setGeometricalObjects(List<GeometricalObject> objects) {
        this.objects = objects;
    }

    
    private MouseEvent press(MouseEvent e){
        for(TransitionSource transition : transitions){
            if(e.getX() > transition.getX() && e.getX() < transition.getX() + 40 && e.getY() > transition.getY() && e.getY() < transition.getY() +40 && play == true){
                    if(transition.isFireable()){
                        ClearingAndAdding();
                        IDt = (int)(long)transition.getId();
                        return e;
                    }
                }
            }
        
        for(PlaceSource place : places){
            long newx = place.getX()+(20);
            long newy = place.getY()+(20);
            long m = (newx - e.getX())*(newx - e.getX());
            long n = (newy - e.getY())*(newy - e.getY());
            double result = sqrt(m+n);
                if(plusTokens == true && result<=(20)*2){
                    plusTokens(e,place);
                }
                   if(minusTokens == true && result<=(20)*2 && place.getMarking()>0){
                    minusTokens(e,place);
                }
            }
        if(drawCircle == true){
            drawCircle(e);
        }
        if(drawTransition == true){
            drawTransition(e);
        }
        if(drawArrow == true){
            drawArrow(e);
        }

        if(RemoveObject == true){
           deleteObject(e);
        }

       return null; 
    }
    private void minusTokens(MouseEvent e, PlaceSource place){
                    place.decreaseMarking(1);
                    ClearingAndAdding();
                    repaint(); 
    }
    private void plusTokens(MouseEvent e, PlaceSource place){
                    place.increaseMarking(1);
                    ClearingAndAdding();
                    repaint();
                
          
    }
    private void drawCircle(MouseEvent e){
            long ID = FindHighestID();
            ID++;
            Circle circle = new Circle((int)(long)e.getX(),(int)(long)e.getY(),20,"",0);
            addGeometricalObject(circle);
            PlaceSource place = new PlaceSource(ID,"",0,e.getX(),e.getY());
            addPlace(place);
            this.net.addPlace(place);
            repaint();
    }
    private void drawTransition(MouseEvent e){
             long ID = FindHighestID();
            ID++;
            TransitionSource transition = new TransitionSource(ID,"",e.getX(),e.getY());
            Square square = new Square((int)(long)e.getX(),(int)(long)e.getY(),40,false,"");
            addGeometricalObject(square);
            addTransition(transition);
            this.net.addTransition(transition);
            repaint();
    }
    private void drawArrow(MouseEvent e){
        int counter = 0;
            if(objectss.size() < 2){
                  for (PlaceSource place : places) {
            long newx = place.getX()+(20);
            long newy = place.getY()+(20);
            long m = (newx - e.getX())*(newx - e.getX());
            long n = (newy - e.getY())*(newy - e.getY());
            double result = sqrt(m+n);
            if(result<=(20)*2){
                    objectss.add(place);
                    counter++;
                    break;
                }
            }
                for (TransitionSource transition : transitions) {
                    if(e.getX() > transition.getX() && e.getX() < transition.getX() + 40 && e.getY() > transition.getY() && e.getY() < transition.getY() +40){
                        objectss.add(transition);
                        counter++;
                        break;
                    }
            }
                if (counter == 0) {
                    if (objectss.size() > 0) {
                        for (Vertex i : objectss) {
                            repaint();
                        }
                        objectss.clear();
                    }
                }
                if (objectss.size() == 1) {
                repaint();
                }
                if (objectss.size() == 2) {
                    repaint();
                    if (objectss.get(0) instanceof PlaceSource && objectss.get(1) instanceof TransitionSource) {
                            long ID = FindHighestID();
                            ID++;
                            PlaceTransitionArc arc = new PlaceTransitionArc(ID,(PlaceSource) objectss.get(0), (TransitionSource) objectss.get(1),1);
                            addArc(arc);
                             Arrow arrow = new Arrow((int)(long)objectss.get(0).getX(),(int)(long)objectss.get(0).getY(),(int)(long)objectss.get(1).getX(),(int)(long)objectss.get(1).getY(),"",1);
                             addGeometricalObject(arrow);
                             lines.put(arc.getID(), arrow.getLine());
                             this.net.addPTArc(ID,(PlaceSource) objectss.get(0), (TransitionSource) objectss.get(1),1);
                            repaint();
                            objectss.clear();
                    }
                    else if (objectss.get(0) instanceof TransitionSource && objectss.get(1) instanceof PlaceSource) {
                            long ID = FindHighestID();
                            ID++;
                            TransitionPlaceArc arc = new TransitionPlaceArc(ID,(TransitionSource) objectss.get(0), (PlaceSource) objectss.get(1),1);
                            addArc(arc);
                            Arrow arrow = new Arrow((int)(long)objectss.get(0).getX(),(int)(long)objectss.get(0).getY(),(int)(long)objectss.get(1).getX(),(int)(long)objectss.get(1).getY(),"",1);  
                            addGeometricalObject(arrow);
                            lines.put(arc.getID(), arrow.getLine());
                            this.net.addTPArc(ID,(TransitionSource) objectss.get(0), (PlaceSource) objectss.get(1),1);
                            repaint();
                            objectss.clear();
                    }
                    else if (objectss.get(0) instanceof PlaceSource && objectss.get(1) instanceof PlaceSource || objectss.get(0) instanceof TransitionSource && objectss.get(1) instanceof TransitionSource) {
                        objectss.clear();
                    }
                }
            }
    }
    private void deleteObject(MouseEvent e){
        if(this.net.getPlaces().size() > 0){
            for(Map.Entry<Long,PlaceSource> place : this.net.getPlaces().entrySet()){
                long newx = place.getValue().getX()+(20);
                long newy = place.getValue().getY()+(20);
                long m = (newx - e.getX())*(newx - e.getX());
                long n = (newy - e.getY())*(newy - e.getY());
                double result = sqrt(m+n);
                if(result<=(20)*2){
                       IDm = (int)(long)place.getValue().getId();
                       deleteplace();
                       deleteplacearc();
                       PN(net);
                       ClearingAndAdding();
                       repaint();
                       break;
                    }
            }

        }
         if(this.net.getTransitions().size() > 0){
             for(Map.Entry<Long,TransitionSource> t : this.net.getTransitions().entrySet()){
                 if( e.getX() > t.getValue().getX() - 40 && e.getX() < t.getValue().getX() + 40 && e.getY() > t.getValue().getY() - 40 && e.getY() < t.getValue().getY() +40 ){
                     IDp = (int)(long)t.getValue().getId();
                     deletetransition();
                     deletetransitionarc();
                     PN(net);
                     ClearingAndAdding();
                     repaint();
                     break;
                 }
            }
         }
         if(this.net.getArcs().size() > 0){
                int radius = 5;      
                for (Map.Entry<Long, Line2D> entry : lines.entrySet()) {
                    if (entry.getValue().intersectsLine(new Line2D.Double(e.getPoint().x, e.getPoint().y - radius, e.getPoint().x, e.getPoint().y + radius)) || entry.getValue().intersectsLine(new Line2D.Double(e.getPoint().x - radius, e.getPoint().y, e.getPoint().x + radius, e.getPoint().y))) {
                        IDa = (int)(long)entry.getKey();
                        deleteArc();
                        PN(net);
                        ClearingAndAdding();
                        repaint();
                        break;
                    }
                }
         }
    }
    private void deletetransition(){
        Iterator<Map.Entry<Long,TransitionSource>> iter = this.net.getTransitions().entrySet().iterator();
        while(iter.hasNext())
        {
            Map.Entry<Long,TransitionSource> transition = iter.next();
            if(transition.getValue().getId() == IDp){
                iter.remove();
            }
        }
    }
    private void deletetransitionarc(){
        Iterator<ArcSource> iter = this.net.getArcs().iterator();
        while(iter.hasNext())
        {
            ArcSource arc = iter.next();
            if(arc.getTransition().getId() == IDp){
                iter.remove();
            }
        }

    }
    private void deleteplace(){
        Iterator<Map.Entry<Long,PlaceSource>> iter = this.net.getPlaces().entrySet().iterator();
        while(iter.hasNext())
        {
            Map.Entry<Long,PlaceSource> place = iter.next();
            if(place.getValue().getId() == IDm){
                iter.remove();
            }
        }

    }
    private void deleteplacearc(){
        Iterator<ArcSource> iter = net.getArcs().iterator();
                while(iter.hasNext())
        {
            ArcSource arc = iter.next();
            if(arc.getPlace().getId() == IDm){
                iter.remove();
            }
        }
    
                
        Iterator<Map.Entry<Long,TransitionSource>> iter2 = net.getTransitions().entrySet().iterator();
        while(iter2.hasNext()){
            
            Map.Entry<Long,TransitionSource> tran = iter2.next();
            Iterator<PlaceTransitionArc> ark = tran.getValue().getInputArcs().iterator();
            while(ark.hasNext()){
                PlaceTransitionArc arc = ark.next();
                if(arc.getSource().getId() == IDm){
                    ark.remove();
                }
            }
            
            Iterator<TransitionPlaceArc> ark2 = tran.getValue().getOutputArcs().iterator();
            while(ark2.hasNext()){
                TransitionPlaceArc arc = ark2.next();
                if(arc.getDestination().getId() == IDm){
                    ark2.remove();
                }
            } 
        }       
    }
    
    private void deleteArc() {
        Iterator<ArcSource> iter = this.net.getArcs().iterator();
        while (iter.hasNext()) {
            ArcSource arc = iter.next();
            if (arc.getID() == IDa) {
                iter.remove();
            }
        }
        
        Iterator<Map.Entry<Long,TransitionSource>> iter2 = net.getTransitions().entrySet().iterator();
        while(iter2.hasNext()){
            
            Map.Entry<Long,TransitionSource> tran = iter2.next();
            Iterator<PlaceTransitionArc> ark = tran.getValue().getInputArcs().iterator();
            while(ark.hasNext()){
                PlaceTransitionArc arc = ark.next();
                if(arc.getID() == IDa){
                    ark.remove();
                }
            }
            
            Iterator<TransitionPlaceArc> ark2 = tran.getValue().getOutputArcs().iterator();
            while(ark2.hasNext()){
                TransitionPlaceArc arc = ark2.next();
                if(arc.getID() == IDa){
                    ark2.remove();
                }
            } 
        }     
    }

    protected void ClearingAndAdding(){
                    objects.clear();
                    addPlaces();
                    addTransitions();
                    addArcs();
    }
    
    @Override
    public void mouseClicked(MouseEvent e) {
         if(e.equals(press(e))){
            Fire();
            addPlaces();
            addTransitions();
            repaint();
        }
    }

    @Override
    public void mousePressed(MouseEvent e) {
        if(MoveObject){
            Buttonpressed = true;
        }
    }
    private void Fire(){
        for(TransitionSource transition : transitions){
            if(transition.getId() == IDt){
                if(transition.isFireable()){
                    transition.fire();
                }
            }
        }
    } 
    private long FindHighestID(){
        long ID = 0;
        for(TransitionSource transition : transitions){
            if(ID < transition.getId()){
                ID = transition.getId();
            }
        }
       for(PlaceSource place : places){
           if(ID < place.getId()){
               ID = place.getId();
           }
       }
       for(ArcSource arc : arcs){
           if(ID < arc.getID()){
               ID = arc.getID();
           }
       }
        return ID;
    }
    @Override
    public void mouseReleased(MouseEvent e) {
        if(MoveObject){
            Buttonpressed = false;
        }
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {   
    }
    
    private void removePlace(PlaceSource place){
        this.net.getPlaces().remove(place);
    }
    private void removeArc(ArcSource arc){
        this.net.getArcs().remove(arc);
    }

    @Override
    public void mouseDragged(MouseEvent me) {
         if (Buttonpressed) {
            boolean touched = false;
            TransitionSource transition = null;
            PlaceSource place = null;
            for (Map.Entry<Long,TransitionSource> i : this.net.getTransitions().entrySet()) {
                if (me.getX() > i.getValue().getX() - 40 && me.getX() < i.getValue().getX() + 40 && me.getY() > i.getValue().getY() - 40 && me.getY() < i.getValue().getY() +40 && touched == false) {
                    touched = true;
                    transition = i.getValue();
                    break;
                }
            }
            for (Map.Entry<Long,PlaceSource> i : this.net.getPlaces().entrySet()) {
                long newx = i.getValue().getX()+(20);
            long newy = i.getValue().getY()+(20);
            long m = (newx - me.getX())*(newx - me.getX());
            long n = (newy - me.getY())*(newy - me.getY());
            double result = sqrt(m+n);
                if (result<=20*2 && touched == false) {
                    touched = true;
                    place = i.getValue();
                    break;
                }

            }
            if (transition != null) {
                transition.setXY(me.getX(), me.getY());
                PN(net);
                ClearingAndAdding();
                repaint();
            }

            if (place != null) {
                place.setXY(me.getX(), me.getY());
                PN(net);
                ClearingAndAdding();
                repaint();
            }
            touched = false;
        }
    }

    @Override
    public void mouseMoved(MouseEvent me) {
    }
 
}
