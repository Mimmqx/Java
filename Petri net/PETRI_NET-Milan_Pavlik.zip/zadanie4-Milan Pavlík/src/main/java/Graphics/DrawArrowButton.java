
package Graphics;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;

public class DrawArrowButton extends JButton implements ActionListener{

        private Screen canvas;
        protected DrawArrowButton(Screen canvas){
        super("Draw arrow");
        this.canvas = canvas;
        addActionListener(this);
    }
    @Override
    public void actionPerformed(ActionEvent ae) {
        canvas.setDrawArrow(true);
        canvas.setButtons(false,false,false,false,false,true,false,false);
    }
    
}
