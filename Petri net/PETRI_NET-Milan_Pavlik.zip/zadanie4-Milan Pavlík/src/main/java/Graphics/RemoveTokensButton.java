
package Graphics;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;

public class RemoveTokensButton extends JButton implements ActionListener{
    
private Screen canvas;
    protected RemoveTokensButton(Screen canvas){
        super("Minus Tokens");
        this.canvas = canvas;
        addActionListener(this);
    }
    @Override
    public void actionPerformed(ActionEvent ae) {
            canvas.setMinusTokens(true);
            canvas.setPlusTokens(false);
            canvas.setButtons(false,false,true,false,false,false,false,false);
    }    
}
