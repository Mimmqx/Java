
package Graphics;
import java.awt.Graphics;

public abstract class GeometricalObject {
    private int x;
    private int y;
    private String title;
    public abstract void draw(Graphics g);

    public GeometricalObject(int x, int y,String title) {
        this.x = x;
        this.y = y;
        this.title = title;
    }

    public GeometricalObject() {
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public void setX(int x) {
        this.x = x;
    }

    public void setY(int y) {
        this.y = y;
    }
    public String getTitle(){
        return title;
    }
}
