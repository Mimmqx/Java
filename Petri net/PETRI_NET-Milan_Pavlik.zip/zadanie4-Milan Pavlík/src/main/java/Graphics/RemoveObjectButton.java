
package Graphics;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;

public class RemoveObjectButton extends JButton implements ActionListener {
    private Screen canvas;
    
    protected RemoveObjectButton(Screen canvas){
        super("Remove object");
        this.canvas = canvas;
        addActionListener(this);
    }
    @Override
    public void actionPerformed(ActionEvent ae) {
        canvas.setRemove(true);
        canvas.setButtons(false,false,false,false,false,false,true,false);
        
    }
    
}
