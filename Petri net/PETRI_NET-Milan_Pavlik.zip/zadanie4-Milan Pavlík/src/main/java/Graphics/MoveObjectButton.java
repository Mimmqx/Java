
package Graphics;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;

public class MoveObjectButton extends JButton implements ActionListener{
    
        private Screen canvas;
        protected MoveObjectButton(Screen canvas){
        super("Move object");
        this.canvas = canvas;
        addActionListener(this);
    }
    @Override
    public void actionPerformed(ActionEvent ae) {
        canvas.setMove(true);
        canvas.setButtons(false,false,false,false,false,false,false,true);
    }
    
}
