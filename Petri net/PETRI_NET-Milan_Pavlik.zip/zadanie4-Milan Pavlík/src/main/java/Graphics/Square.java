
package Graphics;

import java.awt.Color;
import java.awt.Graphics;

public class Square extends GeometricalObject {
    
    private int size;
    private boolean color;
    public Square() {
        super();
    }
    public Square(int size,boolean color) {
        super();
        this.size = size;
        this.color = color;
    }
    public Square(int x, int y, int size,boolean color, String title) {
        super(x,y,title);
        this.size = size;
        this.color = color;
    }

    @Override
    public void draw(Graphics g) {
            
         g.setColor((Color.white));
         g.fillRect(this.getX(), this.getY(), this.size, this.size);
        if(this.color ){
            g.setColor(Color.green);
            g.fillRect(this.getX(), this.getY(), this.size, this.size);
        }
        else{
           g.setColor(Color.black);
           g.drawRect(this.getX(), this.getY(), this.size, this.size);     
                }
        g.setColor(Color.black);
        g.drawString(this.getTitle(), this.getX()-this.size, this.getY()+this.size+10);
        }
    }

