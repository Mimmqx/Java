
package Graphics;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;

public class DrawCircleButton extends JButton implements ActionListener {

    private Screen canvas;
        protected DrawCircleButton(Screen canvas){
        super("Draw circle");
        this.canvas = canvas;
        addActionListener(this);
    }
    @Override
    public void actionPerformed(ActionEvent ae) {
       canvas.setDrawCircle(true);
       canvas.setButtons(false,false,false,true,false,false,false,false);
    }
    
}
