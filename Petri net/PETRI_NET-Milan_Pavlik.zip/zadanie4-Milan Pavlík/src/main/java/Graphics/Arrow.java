package Graphics;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.awt.geom.Line2D;

public class Arrow extends GeometricalObject {

    private final int ARR_SIZE = 4;
    private int x1, y1, x2, y2;
    private int multiplicity;
    private Line2D line;

    public int gety1(){
        return this.y1;
    }
    public int getx1(){
        return this.x1;
    }
    public int getx2(){
        return this.x2;
    }
    public int gety2(){
        return this.y2;
    }
    public Line2D getLine(){
        return this.line;
    }
    public Arrow() {
        super();
    }

    public Arrow(int x2, int y2, int multiplicity) {
        super();
        this.x2 = x2;
        this.y2 = y2;
        this.multiplicity = multiplicity;
        this.line = new Line2D.Double(x1, y1, x2, y2);
    }

    public Arrow(int x, int y, int x2, int y2, String title, int multiplicity) {
        super(x, y, title);
        this.x1 = x;
        this.y1 = y;
        this.x2 = x2;
        this.y2 = y2;
        this.multiplicity = multiplicity;
        this.line = new Line2D.Double(x1, y1, x2, y2);
    }

    @Override
    public void draw(Graphics g) {
        if (this.getX() < x2 && this.getY() > y2 || this.getX() < x2 && this.getY() < y2) {
            drawArrow(g, x1 + 40, y1 + 20, x2, y2 + 20, multiplicity);
        } else if (this.getX() > x2 && this.getY() < y2 || this.getX() > x2 && this.getY() > y2) {
            drawArrow(g, x1, y1 + 20, x2 + 40, y2 + 20, multiplicity);
        } else if (((this.getX() - x2) > - 40 && this.getX() - x2 < 0)) {
            drawArrow(g, x1 - 20, y1 + 20, x2 + 20, y2 - 20, multiplicity);
        } else if (((this.getX() - x2) > 0 && this.getX() - x2 < 40)) {
            drawArrow(g, x1 + 20, y1 + 20, x2 - 20, y2 - 20, multiplicity);
        } else if (this.getX() == x2 && this.getY() < y2) {
            drawArrow(g, x1 + 20, y1 + 40, x2 + 20, y2, multiplicity);
        } else if (this.getX() == x2 && this.getY() > y2) {
            drawArrow(g, x1 + 20, y1, x2 + 20, y2 + 40, multiplicity);
        } else if (this.getY() == y2 && this.getX() < x2) {
            drawArrow(g, x1 + 40, y1 + 20, x2, y2 + 20, multiplicity);
        } else if (this.getY() == y2 && this.getX() > x2) {
            drawArrow(g, x1, y1 + 20, x2 + 40, y2 + 20, multiplicity);
        }
        if (multiplicity > 1) {
            g.drawString(Integer.toString(multiplicity), ((x1 + (40/2)) + (x2 + (40 / 2)) )/ 2, ((y1 + (40 / 2)) + (y2 + (40 / 6)))/ 2);
        }
    }

   private void drawArrow(Graphics g1, int x1, int y1, int x2, int y2, int multiplicity) {
        Graphics2D g = (Graphics2D) g1.create();
        double dx = x2 - x1, dy = y2 - y1;
        double angle = Math.atan2(dy, dx);
        int len = (int) Math.sqrt(dx * dx + dy * dy);
        AffineTransform at = AffineTransform.getTranslateInstance(x1, y1);
        at.concatenate(AffineTransform.getRotateInstance(angle));
        g.transform(at);
        g.setColor(Color.black);
        g.drawLine(0, 0, len, 0);
        g.fillPolygon(new int[]{len, len - ARR_SIZE, len - ARR_SIZE, len},
                new int[]{0, -ARR_SIZE, ARR_SIZE, 0}, 4);
    }
}

