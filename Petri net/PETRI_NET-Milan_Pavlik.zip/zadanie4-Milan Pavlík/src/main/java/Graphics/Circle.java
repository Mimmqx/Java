
package Graphics;
import java.awt.Color;
import java.awt.Graphics;

public class Circle extends GeometricalObject {
    
    private int diameter;
    private String tokens;
    
    public Circle() {
        super();
    }

    public Circle(int diameter, int tokens) {
        super();
        this.diameter = diameter;
        String s = Integer.toString(tokens);
        this.tokens = s;
    }
    public Circle(int x, int y, int diameter, String title,int tokens) {
        super(x,y,title);
        this.diameter = diameter;
        String s = Integer.toString(tokens);
        this.tokens = s;
    }    

    @Override
    public void draw(Graphics g) {
        g.setColor(Color.white);
        g.fillOval(this.getX(), this.getY(), 2*diameter, 2*diameter);
        g.setColor(Color.black);
        g.drawOval(this.getX(), this.getY(), 2*diameter, 2*diameter);
        balls(g);
        g.drawString(this.getTitle(), this.getX()+2*diameter-diameter, this.getY()+2*diameter+diameter);
    } 
    private void balls(Graphics g){
        switch(tokens){
            case "0" : break;
            case "1" : g.fillOval(this.getX()+diameter-4, this.getY()+diameter-4, 2*4, 2*4); //stred
                       break;
            case "2" : g.fillOval(this.getX()+diameter-(2*4)-4, this.getY()+diameter+(2*4)-4, 2*4, 2*4); //4
                       g.fillOval(this.getX()+diameter+(2*4)-4, this.getY()+diameter-(2*4)-4, 2*4, 2*4);//2
                       break;
            case "3" : g.fillOval(this.getX()+diameter-4, this.getY()+diameter-4, 2*4, 2*4); //stred
                       g.fillOval(this.getX()+diameter-(2*4)-4, this.getY()+diameter+(2*4)-4, 2*4, 2*4); //4
                       g.fillOval(this.getX()+diameter+(2*4)-4, this.getY()+diameter-(2*4)-4, 2*4, 2*4);//2
                       break;
            case "4" : g.fillOval(this.getX()+diameter-(2*4)-4, this.getY()+diameter+(2*4)-4, 2*4, 2*4); //4
                       g.fillOval(this.getX()+diameter+(2*4)-4, this.getY()+diameter-(2*4)-4, 2*4, 2*4);//2
                       g.fillOval(this.getX()+diameter+(2*4)-4, this.getY()+diameter+(2*4)-4, 2*4, 2*4);//3
                        g.fillOval(this.getX()+diameter-(2*4)-4, this.getY()+diameter-(2*4)-4, 2*4, 2*4);//1
                       break;
            case "5" : g.fillOval(this.getX()+diameter-(2*4)-4, this.getY()+diameter+(2*4)-4, 2*4, 2*4); //4
                       g.fillOval(this.getX()+diameter+(2*4)-4, this.getY()+diameter-(2*4)-4, 2*4, 2*4);//2
                       g.fillOval(this.getX()+diameter+(2*4)-4, this.getY()+diameter+(2*4)-4, 2*4, 2*4);//3
                       g.fillOval(this.getX()+diameter-(2*4)-4, this.getY()+diameter-(2*4)-4, 2*4, 2*4);//1
                       g.fillOval(this.getX()+diameter-4, this.getY()+diameter-4, 2*4, 2*4); //stred
                       break;
            case "6" : g.fillOval(this.getX()+diameter-(2*4)-4, this.getY()+diameter+(2*4)-4, 2*4, 2*4); //4
                       g.fillOval(this.getX()+diameter-(2*4)-4,this.getY()+diameter-4,2*4, 2*4);//stred lavo
                       g.fillOval(this.getX()+diameter-(2*4)-4, this.getY()+diameter-(2*4)-4, 2*4, 2*4);//1
                       g.fillOval(this.getX()+diameter+(2*4)-4, this.getY()+diameter-(2*4)-4, 2*4, 2*4);//2
                       g.fillOval(this.getX()+diameter+(2*4)-4, this.getY()+diameter+(2*4)-4, 2*4, 2*4);//3
                       g.fillOval(this.getX()+diameter+(2*4)-4,this.getY()+diameter-4,2*4, 2*4);//stred pravo
                       break;
            case "7" : g.fillOval(this.getX()+diameter-(2*4)-4, this.getY()+diameter+(2*4)-4, 2*4, 2*4); //4
                       g.fillOval(this.getX()+diameter-(2*4)-4,this.getY()+diameter-4,2*4, 2*4);//stred lavo
                       g.fillOval(this.getX()+diameter-(2*4)-4, this.getY()+diameter-(2*4)-4, 2*4, 2*4);//1
                       g.fillOval(this.getX()+diameter+(2*4)-4, this.getY()+diameter-(2*4)-4, 2*4, 2*4);//2
                       g.fillOval(this.getX()+diameter+(2*4)-4, this.getY()+diameter+(2*4)-4, 2*4, 2*4);//3
                       g.fillOval(this.getX()+diameter+(2*4)-4,this.getY()+diameter-4,2*4, 2*4);//stred pravo
                       g.fillOval(this.getX()+diameter-4, this.getY()+diameter-4, 2*4, 2*4); //stred
                       break;
            case "8" : g.fillOval(this.getX()+diameter-(2*4)-4, this.getY()+diameter+(2*4)-4, 2*4, 2*4); //4
                       g.fillOval(this.getX()+diameter-(2*4)-4,this.getY()+diameter-4,2*4, 2*4);//stred lavo
                       g.fillOval(this.getX()+diameter-(2*4)-4, this.getY()+diameter-(2*4)-4, 2*4, 2*4);//1
                       g.fillOval(this.getX()+diameter+(2*4)-4, this.getY()+diameter-(2*4)-4, 2*4, 2*4);//2
                       g.fillOval(this.getX()+diameter+(2*4)-4, this.getY()+diameter+(2*4)-4, 2*4, 2*4);//3
                       g.fillOval(this.getX()+diameter+(2*4)-4,this.getY()+diameter-4,2*4, 2*4);//stred pravo
                       g.fillOval(this.getX()+diameter-4,this.getY()+diameter-(2*4)-4,2*4, 2*4);//stred hore
                       g.fillOval(this.getX()+diameter-4,this.getY()+diameter+(2*4)-4,2*4, 2*4);//stred dole
                       break;
            case "9" : g.fillOval(this.getX()+diameter-(2*4)-4, this.getY()+diameter+(2*4)-4, 2*4, 2*4); //4
                       g.fillOval(this.getX()+diameter-(2*4)-4,this.getY()+diameter-4,2*4, 2*4);//stred lavo
                       g.fillOval(this.getX()+diameter-(2*4)-4, this.getY()+diameter-(2*4)-4, 2*4, 2*4);//1
                       g.fillOval(this.getX()+diameter+(2*4)-4, this.getY()+diameter-(2*4)-4, 2*4, 2*4);//2
                       g.fillOval(this.getX()+diameter+(2*4)-4, this.getY()+diameter+(2*4)-4, 2*4, 2*4);//3
                       g.fillOval(this.getX()+diameter+(2*4)-4,this.getY()+diameter-4,2*4, 2*4);//stred pravo
                       g.fillOval(this.getX()+diameter-4,this.getY()+diameter-(2*4)-4,2*4, 2*4);//stred hore
                       g.fillOval(this.getX()+diameter-4,this.getY()+diameter+(2*4)-4,2*4, 2*4);//stred dole
                       g.fillOval(this.getX()+diameter-4, this.getY()+diameter-4, 2*4, 2*4); //stred
                       break;
            default  : g.drawString(tokens, this.getX()+20, this.getY()+20);
            }
    }
}


