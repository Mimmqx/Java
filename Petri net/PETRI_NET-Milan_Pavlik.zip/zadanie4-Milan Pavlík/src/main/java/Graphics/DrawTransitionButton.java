
package Graphics;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;

public class DrawTransitionButton extends JButton implements ActionListener {

     private Screen canvas;
        protected DrawTransitionButton(Screen canvas){
        super("Draw transition");
        this.canvas = canvas;
        addActionListener(this);
    }
    @Override
    public void actionPerformed(ActionEvent ae) {
        canvas.setdrawTransition(true);
        canvas.setButtons(false,false,false,false,true,false,false,false);
    }
    
}
