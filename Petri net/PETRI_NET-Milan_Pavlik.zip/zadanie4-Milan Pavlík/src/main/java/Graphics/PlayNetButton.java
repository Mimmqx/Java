
package Graphics;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import sk.stuba.fei.oop.TransitionSource;


public class PlayNetButton extends JButton implements ActionListener {
    private Screen canvas;
    
    protected PlayNetButton(Screen canvas){
        super("Play net");
        this.canvas = canvas;
        addActionListener(this);
    }
    @Override
    public void actionPerformed(ActionEvent ae) {
        if(!canvas.play){
                canvas.setButtons(true,false,false,false,false,false,false,false);
                for(TransitionSource transition : canvas.getTransitions()){
                    if(transition.isFireable()){
                        canvas.ClearingAndAdding();
                    }
                }
                canvas.repaint();
        }
    }
    
}
