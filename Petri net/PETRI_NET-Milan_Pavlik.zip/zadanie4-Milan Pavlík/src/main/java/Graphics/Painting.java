
package Graphics;

import java.awt.BorderLayout;
import java.awt.MenuBar;
import java.awt.MenuItem;
import java.awt.Panel;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JFrame;
import sk.stuba.fei.oop.PetriNet;

public class Painting extends JFrame {
    private MenuItem ExitItem;
    private MenuItem OpenFile;
    private Screen canvas;
    
        public Painting(PetriNet net){
            super("Moj editor");
            Panel panel = new Panel();
            setLayout(new BorderLayout()); 
            setExtendedState(JFrame.MAXIMIZED_BOTH);
            setTitle("Zadanie 3");
            canvas = new Screen();
            canvas.PN(net);
//            canvas.addMouseListener(canvas);
            add("South",panel);
            add("Center",canvas);
            MenuBar bar = new MenuBar();
            setMenuBar(bar);
           
            panel.add(new AddingTokensButton(canvas),BorderLayout.LINE_END);
            panel.add(new RemoveTokensButton(canvas),BorderLayout.LINE_END);
            panel.add(new PlayNetButton(canvas),BorderLayout.LINE_END);
            panel.add(new DrawCircleButton(canvas),BorderLayout.LINE_END);
            panel.add(new DrawTransitionButton(canvas),BorderLayout.LINE_END);
            panel.add(new DrawArrowButton(canvas),BorderLayout.LINE_END);
            panel.add(new RemoveObjectButton(canvas),BorderLayout.LINE_END);
            panel.add(new MoveObjectButton(canvas),BorderLayout.LINE_END);
            
            Menuu file=new Menuu(canvas,net,this);
            bar.add(file);

            net = canvas.getNet();
            
            addWindowListener(new WindowAdapter ()
                                   {   public void windowClosing (WindowEvent e)
                                      {System.exit(0);}
                                   }
                               );
            
            setVisible(true);
    }

}