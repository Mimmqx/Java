
package Graphics;

import java.awt.FileDialog;
import java.awt.Menu;
import java.awt.MenuItem;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import sk.stuba.fei.oop.Parse;
import sk.stuba.fei.oop.PetriNet;
import sk.stuba.fei.oop.Save;
import sk.stuba.fei.oop.generated.Document;


public class Menuu extends Menu implements ActionListener {
    private MenuItem ExitItem;
    private MenuItem SaveFile;
    private MenuItem OpenFile;
    private Screen canvas;
    private PetriNet net ;
    private Painting frame;
    
    protected Menuu(Screen canvas,PetriNet net, Painting frame){
        super("Menu");
        this.canvas = canvas;
        this.net = net;
        this.frame = frame;

        OpenFile=new MenuItem("Open");
        OpenFile.addActionListener(this);
        this.add(OpenFile);
        
        SaveFile=new MenuItem("Save");
        SaveFile.addActionListener(this);
        this.add(SaveFile);
        
        ExitItem=new MenuItem("Exit");
        ExitItem.addActionListener(this);
        this.add(ExitItem);
    }
    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource()==ExitItem)
            {   
                System.exit(0);
            }
        if (ae.getSource()==OpenFile)
        {
            FileDialog OpDialog = new FileDialog(this.frame,"Open",FileDialog.LOAD);
            OpDialog.setVisible(true);
            
            PetriNet net = new PetriNet();
            Parse pars = new Parse();
            Document doc = new Document();
            
            String s = OpDialog.getDirectory() + OpDialog.getFile();
            if (OpDialog.getFile()!=null) {
                    try{
            File file = new File(s);
            JAXBContext jaxbContext = JAXBContext.newInstance(Document.class);
            Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
            doc = (Document) jaxbUnmarshaller.unmarshal(file); 
            System.out.println(doc);
                        }
                    catch (JAXBException e)
                         {   
                             e.printStackTrace();
                         }
                    this.net.allRestet();
                    this.net = pars.CreateNet(doc);
                    canvas.clearList();
                    canvas.PN(this.net);
                    canvas.repaint();         
            }  
        }
        if (ae.getSource()==SaveFile)
            {
                 FileDialog fd = new FileDialog(this.frame, "Save file ", FileDialog.SAVE);
                 fd.setDirectory("src/main/");
                 fd.setFile("output.xml");
                 fd.setVisible(true);
                 if (fd.getDirectory() == null) {
                        JOptionPane.showMessageDialog(this.frame, "You have not save your Petri's network");
                    } else {
                        new Save(this.net, fd);
                    }
            }
    }
    
}
