
package sk.stuba.fei.oop;

import java.awt.FileDialog;
import java.io.File;
import java.io.InputStream;
import java.util.Map;
import javax.swing.JOptionPane;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import sk.stuba.fei.oop.generated.Arc;
import sk.stuba.fei.oop.generated.Document;
import sk.stuba.fei.oop.generated.Place;
import sk.stuba.fei.oop.generated.Transition;

public class Save {

    private Document documentToSave = new Document();
    private PetriNet net;
    private FileDialog filedialog;

    public Save(PetriNet net, FileDialog filedialog){
        this.net = net;
        this.filedialog = filedialog;
        setFile();
        FinalSaveOfPetriNet();
    }

    private void setFile(){
        for(Map.Entry<Long,PlaceSource> map : net.getPlaces().entrySet()){
            Place place = new Place();
            place.setId((short) (long) map.getValue().getId());
            place.setLabel( map.getValue().getLabel());
            place.setX((short) (long) map.getValue().getX());
            place.setY((short) (long) map.getValue().getY());
            place.setTokens( (short) map.getValue().getMarking());
            documentToSave.getPlace().add(place);
        }
         for(Map.Entry<Long,TransitionSource> map : net.getTransitions().entrySet()){
            Transition transition = new Transition();
            transition.setId((short) (long) map.getValue().getId());
            transition.setLabel( map.getValue().getLabel());
            transition.setX((short) (long) map.getValue().getX());
            transition.setY((short) (long) map.getValue().getY());
            documentToSave.getTransition().add(transition);
        }
        for (ArcSource a : net.getArcs()){
            Arc arc = new Arc();
            arc.setId((short) a.getID());
            arc.setMultiplicity((short) a.getMultiplicity());
            arc.setSourceId((short) (long)a.getSource().getId());
            arc.setDestinationId((short)(long) a.getDestination().getId());
            arc.setType("regular");
            documentToSave.getArc().add(arc);
        }
    }
        private void FinalSaveOfPetriNet() {
        try {
            JAXBContext jaxbContext = JAXBContext.newInstance(Document.class);
            Marshaller marshaller = jaxbContext.createMarshaller();
            marshaller.marshal(documentToSave, new File(filedialog.getDirectory() + filedialog.getFile()));
        } catch (JAXBException ignored) {
            ignored.printStackTrace();
            System.err.println(ignored.getMessage());
        }
    }
}
