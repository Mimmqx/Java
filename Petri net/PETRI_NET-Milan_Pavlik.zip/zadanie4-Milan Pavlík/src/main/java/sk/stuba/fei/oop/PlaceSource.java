
package sk.stuba.fei.oop;

public class PlaceSource extends Vertex {
    private int marking = 0;

    public PlaceSource(long id, String title, int marking, long x, long y) throws IllegalArgumentException {
        this(id, title,x,y);
        setMarking(marking);
    }

    public PlaceSource(long id, String title, long x , long y) {
        super(id, title,x,y);
    }

    public int getMarking() {
        return marking;
    }

    public void setMarking(int marking) throws IllegalArgumentException {
        if (marking < 0)
            throw new IllegalArgumentException("Marking can not be negative number.");
        this.marking = marking;
    }

    public void increaseMarking(int value) throws IllegalArgumentException {
        setMarking(marking + value);
    }

    public void decreaseMarking(int value) throws IllegalArgumentException {
        setMarking(marking - value);
    }
}
