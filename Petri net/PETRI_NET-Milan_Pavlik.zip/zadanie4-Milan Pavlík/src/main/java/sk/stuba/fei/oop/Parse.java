
package sk.stuba.fei.oop;

import java.util.Map;
import sk.stuba.fei.oop.generated.Document;
import sk.stuba.fei.oop.generated.Place;
import sk.stuba.fei.oop.generated.Transition;
import sk.stuba.fei.oop.generated.Arc;

public class Parse {
        private void parsePlaces(Document doc, PetriNet net){
            for(Place p : doc.getPlace()){
                PlaceSource place = new PlaceSource((int)(long)p.getId(),p.getLabel(),p.getTokens(),p.getX(),p.getY());
                net.addPlace(place);
                }
        }
        private void parseTransitions(Document doc, PetriNet net){
            for( Transition t : doc.getTransition()){
                TransitionSource transition = new TransitionSource(t.getId(),t.getLabel(),t.getX(),t.getY());
                net.addTransition(transition);
            }
        }
       private void parseTPArc(Document doc, PetriNet net){
            for( Arc a : doc.getArc()){
            for(Map.Entry<Long,TransitionSource> map : net.getTransitions().entrySet()){
                if(map.getKey() == a.getSourceId()){
                    for(Map.Entry<Long,PlaceSource> map2 : net.getPlaces().entrySet()){
                        if(map2.getKey() == a.getDestinationId()){
                            TransitionPlaceArc arc1 = new TransitionPlaceArc(a.getId(),map.getValue(),map2.getValue(),a.getMultiplicity());
                            net.addTPArc(a.getId(),map.getValue(),map2.getValue(),a.getMultiplicity());
                            
                        }
                    }
                }
            }
        }
       }
        private void parsePTArc(Document doc, PetriNet net){
            for( Arc a : doc.getArc()){
            for(Map.Entry<Long,PlaceSource> map : net.getPlaces().entrySet()){
                if(map.getKey() == a.getSourceId()){
                    for(Map.Entry<Long,TransitionSource> map2 : net.getTransitions().entrySet()){
                        if(map2.getKey() == a.getDestinationId()){
                            PlaceTransitionArc arc1 = new PlaceTransitionArc(a.getId(),map.getValue(),map2.getValue(),a.getMultiplicity());
                            net.addPTArc(a.getId(),map.getValue(),map2.getValue(),a.getMultiplicity());
                        }
                    }
                }
            }
        }
       }
        public PetriNet CreateNet(Document doc){
        PetriNet net = new PetriNet();
        parsePlaces(doc,net);
        parseTransitions(doc,net);
        parseTPArc(doc,net);
        parsePTArc(doc,net);
        return net;
    }
}