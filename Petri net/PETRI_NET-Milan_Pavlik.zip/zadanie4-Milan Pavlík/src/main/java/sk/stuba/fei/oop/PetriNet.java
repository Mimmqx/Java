
package sk.stuba.fei.oop;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class PetriNet {
    private Map<Long, PlaceSource> places = new HashMap<Long,PlaceSource>();
    private Map<Long, TransitionSource> transitions = new HashMap<Long,TransitionSource>();
    private Set<ArcSource> arcs = new HashSet<ArcSource>();

    public Map<Long,PlaceSource> getPlaces(){
        return this.places;
    }
    public Map<Long,TransitionSource> getTransitions(){
        return this.transitions;
    }
    public Set<ArcSource> getArcs(){
        return this.arcs;
    }
    public void allRestet(){
        places.clear();
        transitions.clear();
        arcs.clear();
    }
    
    public void fireTransition(long transitionId) {
        TransitionSource transition = transitions.get(transitionId);
        if (transition == null)
            throw new IllegalArgumentException();
        transition.fire();
    }

    public void addPlace(PlaceSource place) {
        places.put(place.getId(), place);
    }

    public void addTransition(TransitionSource transition) {
        transitions.put(transition.getId(), transition);
    }

    public void addPTArc(long id,PlaceSource p, TransitionSource t,int multiplicity) {
        PlaceTransitionArc arc = new PlaceTransitionArc(id,p, t,multiplicity);
        t.addInputArc(arc);
        arcs.add(arc);
    }

    public void addTPArc(long id,TransitionSource t, PlaceSource p, int multiplicity) {
        TransitionPlaceArc arc = new TransitionPlaceArc(id,t, p,multiplicity);
        t.addOutputArc(arc);
        arcs.add(arc);
    }
}
