
package sk.stuba.fei.oop;

public abstract class Vertex {
        
    private long id;
    private String title;
    private long x;
    private long y;
    protected Vertex(long id, String title,long x, long y) {
        this.id = id;
        this.title = title;
        this.x = x;
        this.y = y;
    }

    public Long getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }
    
    public Long getX() {
        return x;
    }
    
    public Long getY() {
        return y;
    }
    public void setXY(int x, int y) {
        this.x = x;
        this.y = y;
    }
    public String getLabel(){
        return this.title;
    }
}
