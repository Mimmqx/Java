
package sk.stuba.fei.oop;

import java.util.HashSet;
import java.util.Set;

public class TransitionSource extends Vertex {
    private Set<PlaceTransitionArc> inputArcs = new HashSet<PlaceTransitionArc>();
    private Set<TransitionPlaceArc> outputArcs = new HashSet<TransitionPlaceArc>();

    public Set<TransitionPlaceArc> getOutputArcs(){
        return this.outputArcs;
    }
    public Set<PlaceTransitionArc> getInputArcs(){
        return this.inputArcs;
    }
    public TransitionSource(long id, String title,long x,long y) {
        super(id, title,x,y);
    }

    public boolean isFireable() {
        for (PlaceTransitionArc inputArc : inputArcs) {
            if (!inputArc.isSatisfied()) {
                return false;
            }
        }
        return true;
    }

    public void fire() {
        if (!isFireable())
            throw new IllegalStateException("Transition " + getTitle() + " is not fireable.");

        for (PlaceTransitionArc inputArc : inputArcs) {
            inputArc.consume();
        }

        for (TransitionPlaceArc outputArc : outputArcs) {
            outputArc.produce();
        }
    }

    public void addInputArc(PlaceTransitionArc arc) throws IllegalArgumentException {
        addArc(arc, inputArcs);
    }

    public void addOutputArc(TransitionPlaceArc arc) throws IllegalArgumentException {
        addArc(arc, outputArcs);
    }

    private <T extends ArcSource> void addArc(T arc, Set<T> arcs) {
        if (arc.getTransition() != this)
            throw new IllegalArgumentException();
        arcs.add(arc);
    }
}
