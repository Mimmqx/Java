
package sk.stuba.fei.oop;


public abstract class ArcSource {
    private Vertex source;
    private Vertex destination;
    private int multiplicity = 1;
    private long id;
    public ArcSource(long id,Vertex source, Vertex destination, int multiplicity) throws IllegalArgumentException {
        this(source, destination);
        this.multiplicity=multiplicity;
        this.id = id;
    }

    public ArcSource(Vertex source, Vertex destination) {
        if (source == null || destination == null)
            throw new IllegalArgumentException("Can not create arc from/to null vertex");
        this.source = source;
        this.destination = destination;
    }

    public int getMultiplicity() {
        return multiplicity;
    }

    public void setMultiplicity(int multiplicity) throws IllegalArgumentException {
        if (multiplicity < 1)
            throw new IllegalArgumentException("Multiplicity can not be less than 1.");

        this.multiplicity = multiplicity;
    }

    public Vertex getSource() {
        return source;
    }

    public Vertex getDestination() {
        return destination;
    }
    public long getID(){
        return this.id;
    }
    public abstract PlaceSource getPlace();

    public abstract TransitionSource getTransition();
}
