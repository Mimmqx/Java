
package sk.stuba.fei.oop;

public class PlaceTransitionArc extends ArcSource {
    public PlaceTransitionArc(long id,PlaceSource source, TransitionSource destination, int multiplicity) throws IllegalArgumentException {
        super(id,source, destination, multiplicity);
    }

    public PlaceTransitionArc(PlaceSource source, TransitionSource destination) {
        super(source, destination);
    }

    public boolean isSatisfied() {
        return getPlace().getMarking() >= getMultiplicity();
    }

    public void consume() {
        getPlace().decreaseMarking(getMultiplicity());
    }

    @Override
    public PlaceSource getPlace() {
        return (PlaceSource) getSource();
    }

    @Override
    public TransitionSource getTransition() {
        return (TransitionSource) getDestination();
    }
}
