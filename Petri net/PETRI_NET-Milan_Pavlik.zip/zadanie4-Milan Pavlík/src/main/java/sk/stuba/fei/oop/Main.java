package sk.stuba.fei.oop;

import Graphics.Painting;

public class Main {

    public static void main(String[] args) {
        new Painting(new PetriNet());   
    }
}
