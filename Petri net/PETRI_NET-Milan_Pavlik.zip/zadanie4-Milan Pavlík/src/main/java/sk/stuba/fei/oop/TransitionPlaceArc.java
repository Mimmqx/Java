
package sk.stuba.fei.oop;

public class TransitionPlaceArc extends ArcSource {
    public TransitionPlaceArc(long id, TransitionSource source, PlaceSource destination, int multiplicity) throws IllegalArgumentException {
        super(id,source, destination, multiplicity);
    }

    public TransitionPlaceArc(TransitionSource source, PlaceSource destination) {
        super(source, destination);
    }

    public void produce() {
        ((PlaceSource) getDestination()).increaseMarking(getMultiplicity());
    }

    @Override
    public PlaceSource getPlace() {
        return (PlaceSource) getDestination();
    }

    @Override
    public TransitionSource getTransition() {
        return (TransitionSource) getSource();
    }
}
